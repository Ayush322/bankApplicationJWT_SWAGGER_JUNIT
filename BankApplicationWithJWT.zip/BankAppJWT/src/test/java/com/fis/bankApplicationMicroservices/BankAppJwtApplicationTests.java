package com.fis.bankApplicationMicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAppJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
