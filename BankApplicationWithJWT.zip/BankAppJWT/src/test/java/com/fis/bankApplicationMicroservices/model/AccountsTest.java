package com.fis.bankApplicationMicroservices.model;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
 
import org.junit.jupiter.api.Test;

import com.fis.bankApplicationMicroservices.model.Accounts;

public class AccountsTest {
	Accounts account = new Accounts();
	
	
 
	@Test
	void setAcctIDTest() {
		account.setAcctID(123);
		assertEquals(124, account.getAcctID());
		
	}
	
	
	@Test
	void setBalanceDataTest() {
		account.setBalance(20000);
		assertEquals(20000, account.getBalance());
	}

}
